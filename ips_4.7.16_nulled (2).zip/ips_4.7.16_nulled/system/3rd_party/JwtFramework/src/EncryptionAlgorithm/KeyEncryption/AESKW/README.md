AES Key Wrapping Based Key Encryption Algorithms For JWT-Framework
==================================================================

This repository is a sub repository of [the JWT Framework](https://github.com/web-token/jwt-framework) project and is READ ONLY.

**Please do not submit any Pull Request here.**
You should go to [the main repository](https://github.com/web-token/jwt-framework) instead.

# Documentation

The official documentation is available as https://web-token.spomky-labs.com/ 

# Licence

This software is release under [MIT licence](LICENSE).
